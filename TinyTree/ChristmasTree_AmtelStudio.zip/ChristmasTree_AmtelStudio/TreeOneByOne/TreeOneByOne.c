/*
 * TreeOneByOne.c
 * Version pour ATTiny45 ou ATTiny85 
 * Created: 28/02/2014 14:42:12 Amtel Studio 6.1
 *  Author: Mic-Josi
 */ 


# define F_CPU 8000000UL

# include <avr/io.h>
# include <util/delay.h>

#define byte uint8_t
#define LED_COUNT 9
#define DDR_BYTE 0
#define PORT_BYTE 1



byte matrix[LED_COUNT][2] = {
	//( GPIO agencement for 2 LED with only one port out)
	// DDR_BYTE         PORT_BYTE   ( Combinaison pour l'allumage de 2 LED avec un seul port de sortie )
	{0b00010001	, 0b00010000},//L1-PB4               1
	{0b00010001	, 0b00000001},//L2-PB4           "     "
	{0b00001001	, 0b00001000},//L3-PB3          " 2    3 "               **     Pin-Tree     **
	{0b00001001	, 0b00000001},//L4-PB3        "      4     "                 L1+ L2- Pin 3
	{0b00000101	, 0b00000100},//L5-PB2      " 5            7 "               L3+ L4- Pin 2
	{0b00000101	, 0b00000001},//L6-PB2     "                   "             L5+ L6- Pin 7
	{0b00000011	, 0b00000010},//L7-PB1    " 6                 8  "           L7+ L8- Pin 6
	{0b00000011	, 0b00000001},//L8-PB1   """""""""""""""""""""""""""   ** +- Commun PB0 Pin 5 **
	//                                             *       *
	//                                             Pin_Tree
};


//*******************************************************
void turnOn( byte led ) // PBx selection
{
	DDRB = matrix[led][DDR_BYTE];
	PORTB = matrix[led][PORT_BYTE];
}
//*******************************************************

//*******************************************************
//very small Delay function from AVRFreaks 
void delay_ms(int ms) {
	int i;
	for (i=0; i< ms; i++) {
		_delay_ms(1);
	}
}
//*******************************************************

//*******************************************************
void SomeOne (byte frame,byte l1,byte l2,byte l3,byte l4,byte l5,byte l6,byte l7,byte l8,byte spd) // some LEDs ON one by one spd time
{  
	
    int figure [9]= {0,0,0,0,0,0,0,0,0};
	
	int light = 0;
	int allume = 0;
	byte l9 = 8;
	while (light < frame)
	{
		for( byte l = 0; l < LED_COUNT; l++ )
		
	  	{
			switch (l)
			{
			case 0:
			figure [l] = l1;
			break;	
			
			case 1:
			figure [l] = l2;
			break;
			
			case 2:
			figure [l] = l3;
			break;
			
			case 3:
			figure [l] = l4;
			break;
			
			case 4:
			figure [l] = l5;
			break;
			
			case 5:
			figure [l] = l6;
			break;
			
			case 6:
			figure [l] = l7;
			break;
			
			case 7:
			figure [l] = l8;
			break;
			
			case 8:
			figure [l] = l9;
			break;
			} 
			
			
		}
		for( byte l = 0; l < LED_COUNT; l++ )
		{
		 allume = figure[l];
		 turnOn(allume);
		 delay_ms(spd);
		} 
		
		light ++;
	}
	delay_ms(100);

}





//*******************************************************
//this animation was tested with ATtiny13A maybe it need to
//change some tempo  
//=======================================================
int main(void)
{
     
    while(1)
    {
	  
   SomeOne (5,0,1,2,3,4,5,6,7,200); // une par une lent
   SomeOne (6,0,1,2,3,4,5,6,7,100); // une par une moyen
   SomeOne (8,0,1,2,3,4,5,6,7,50); // une par une rapide
   SomeOne (60,0,1,2,3,4,5,6,7,1);  // flash
   SomeOne (7,0,2,3,1,8,8,8,8,100);// carr� haut lent
   SomeOne (7,1,0,2,8,8,8,8,8,120);// petit triangle haut lent
   SomeOne (7,1,3,2,8,8,8,8,8,110);// petit triangle haut invers� lent
   SomeOne (8,6,4,1,0,2,5,7,8,100); // grand triangle lent
   //SomeOne (7,1,0,4,6,1,0,4,6,100); // grand triangle lent
  // SomeOne (7,1,0,4,6,7,5,2,1,100); // grand triangle lent
  // SomeOne (7,4,1,0,2,5,8,8,8,100); // triangle moyen lent
   SomeOne (7,4,3,5,4,3,5,8,8,120);// triangle milieu lent
   SomeOne (7,4,1,2,5,4,1,2,5,120); // trap�ze haut lent
   SomeOne (7,6,4,5,7,6,4,5,7,120); //trap�ze bas lent
   SomeOne (10,1,0,2,3,4,5,6,7,20); // une par une rapide
   SomeOne (8,0,2,3,1,0,2,3,1,85);// carr� haut rapide
   SomeOne (8,0,2,1,8,8,0,2,1,85);// petit triangle haut rapide
   SomeOne (8,1,2,3,8,8,1,2,3,85);// petit triangle haut invers� rapide
   SomeOne (8,6,4,1,0,2,5,7,8,55); // grand triangle rapide
   SomeOne (8,4,1,0,2,5,8,8,8,55); // triangle moyen rapide
   SomeOne (8,8,8,8,3,4,5,8,8,75);// triangle milieu rapide
   SomeOne (8,4,1,2,5,4,1,2,5,85); // trap�ze haut rapide
   SomeOne (8,4,5,6,7,4,5,6,7,85); //trap�ze bas rapide
   SomeOne (8,3,0,3,4,3,5,3,0,55); //�toile rapide
   SomeOne (8,3,5,4,0,3,5,4,0,25); //�toile1 rapide
   SomeOne (8,8,4,1,3,2,5,8,8,75); //petit M rapide
   SomeOne (8,8,6,4,1,3,2,5,7,55); //grand M rapide
    }
}
//=======================================================